
from tkinter import *
from tkinter import ttk
import tkinter.messagebox as MessageBox
from turtle import clearscreen
window=Tk()
window.title("Employee Management System")

window.configure(bg='light grey')
import mysql.connector 
mycon=mysql.connector.connect(host='localhost',
                   user='root',
                   passwd='root',
                   database='Employee_Management')
if mycon.is_connected()== False:
    print('Error connecting to MySQL Database')

else:
    cursor=mycon.cursor()
    
def viewall():
    cursor.execute("select * from employees")
    row=cursor.fetchall()
    for column in row:
        insertdata=str(column)
        list1.insert(list1.size()+1,insertdata)
def addemployee():
    e_no=e1.get()
    e_name=e2.get()
    e_address=e3.get()
    e_phoneno=e4.get()
    if(e_no=="" or e_name=="" or e_address== "" or e_phoneno==""):
        MessageBox.showinfo("Insert status","Fill all the fields")
    else:
        st="insert into employees(e_no,e_name,e_address,e_phoneno) values({},'{}','{}','{}')".format(e_no,e_name,e_address,e_phoneno)
        cursor.execute(st)
        mycon.commit()
        print("one row inserted")
        e1.delete(0,'end')
        e2.delete(0,'end')
        e3.delete(0,'end')
        e4.delete(0,'end')
def updateemployee():
    e_no=e1.get()
    e_name=e2.get()
    e_address=e3.get()
    e_phoneno=e4.get()
    if(e_no=="" or e_name=="" or e_address== "" or e_phoneno==""):
        MessageBox.showinfo("update status","Fill all the fields")
    else:
        st="update employees set e_name='{}',e_address='{}',e_phoneno='{}' where e_no={}".format(e_name,e_address,e_phoneno,e_no)
        cursor.execute(st)
        mycon.commit()
        print("one row updated")
        e1.delete(0,'end')
        e2.delete(0,'end')
        e3.delete(0,'end')
        e4.delete(0,'end')
def searchemployee():
    e_no=e1.get()
    if(e_no==""):
        MessageBox.showinfo("search status","Employee Number is necessary")
    else:
        cursor.execute("select * from employees where e_no={}".format(e_no))
        rows=cursor.fetchall()
        for column in rows:
         insertdata=str(column)
         list1.insert(list1.size()+1,insertdata)   
def deleteemployee():
    e_no=e1.get()
    if(e_no==""):
        MessageBox.showinfo("Delete status","Employee Number is necessary")
    else:
        st="delete from employees where e_no={}".format(e_no)
        cursor.execute(st)
        mycon.commit()
        print("one row deleted")    
def close():
    res=MessageBox.askquestion(message="Do you want to exit, press yes or no")
    if res== 'yes':
        window.destroy()     
                    
#Labels
l1=Label(window,text="Employee ID",width=15)
l1.grid(row=0,column=0)
l2=Label(window,text="Employee Name",width=15)
l2.grid(row=0,column=2)
l3=Label(window,text="Email Address",width=15)
l3.grid(row=1,column=0)
l4=Label(window,text="Phone Number",width=15)
l4.grid(row=1,column=2)
#Entries
no_text=StringVar()
e1=Entry(window,textvariable=no_text)
e1.grid(row=0,column=1)
name_text=StringVar()
e2=Entry(window,textvariable=name_text)
e2.grid(row=0,column=3)
address_text=StringVar()
e3=Entry(window,textvariable=address_text)
e3.grid(row=1,column=1)
phoneno_text=StringVar()
e4=Entry(window,textvariable=phoneno_text)
e4.grid(row=1,column=3)
#listbox
list1=Listbox(window,height=25,width=80)
list1.grid(row=2,column=0,rowspan=6,columnspan=2)
sb1=Scrollbar(window)
sb1.grid(row=2,column=2,rowspan=6)
list1.configure(yscrollcommand=sb1.set)
sb1.configure(command=list1.yview)
#button
b1=Button(window,text="View All",height=2,width=50,command=viewall)
b1.grid(row=2,column=3)
b1=Button(window,text="Search Employee",height=2,width=50,command=searchemployee)
b1.grid(row=3,column=3)
b1=Button(window,text="Add Employee",height=2,width=50,command=addemployee)
b1.grid(row=4,column=3)
b1=Button(window,text="Update Employee",height=2,width=50,command=updateemployee)
b1.grid(row=5,column=3)
b1=Button(window,text="Delete Employee",height=2,width=50,command=deleteemployee)
b1.grid(row=6,column=3)
b1=Button(window,text="Close",height=2,width=50,command=close)
b1.grid(row=7,column=3)
window.mainloop()